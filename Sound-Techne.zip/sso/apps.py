from django.apps import AppConfig


class SsoConfig(AppConfig):
    name = 'sso'
